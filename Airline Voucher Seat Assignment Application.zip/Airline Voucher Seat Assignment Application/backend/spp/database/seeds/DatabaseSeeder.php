<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Voucher;
use Carbon\Carbon;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Clear existing records
        Voucher::truncate();

        // Seed sample voucher data for testing
        $sampleVouchers = [
            [
                'crew_name' => 'John Smith',
                'crew_id' => 'CS1001',
                'flight_number' => 'GA101',
                'flight_date' => '2025-07-10',
                'aircraft_type' => 'Airbus 320',
                'seat1' => '12A',
                'seat2' => '12B',
                'seat3' => '12C',
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
                'crew_name' => 'Emma Watson',
                'crew_id' => 'CS1002',
                'flight_number' => 'ID202',
                'flight_date' => '2025-07-11',
                'aircraft_type' => 'Boeing 737 Max',
                'seat1' => '5F',
                'seat2' => '6A',
                'seat3' => '6B',
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
                'crew_name' => 'Michael Brown',
                'crew_id' => 'CS1003',
                'flight_number' => 'AT303',
                'flight_date' => '2025-07-12',
                'aircraft_type' => 'ATR',
                'seat1' => '3A',
                'seat2' => '3C',
                'seat3' => '4D',
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
                'crew_name' => 'Sarah Johnson',
                'crew_id' => 'CS1004',
                'flight_number' => 'GA404',
                'flight_date' => '2025-07-13',
                'aircraft_type' => 'Airbus 320',
                'seat1' => '20A',
                'seat2' => '20B',
                'seat3' => '21C',
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ],
            [
                'crew_name' => 'David Lee',
                'crew_id' => 'CS1005',
                'flight_number' => 'ID505',
                'flight_date' => '2025-07-14',
                'aircraft_type' => 'Boeing 737 Max',
                'seat1' => '15D',
                'seat2' => '15E',
                'seat3' => '16F',
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ]
        ];

        // Insert sample data
        foreach ($sampleVouchers as $voucher) {
            Voucher::create($voucher);
        }

        // Display info in console
        $this->command->info('Sample voucher data seeded successfully!');
        $this->command->info('Total vouchers created: ' . count($sampleVouchers));
        
        // Show seeded data summary
        $this->command->table(
            ['Flight Number', 'Date', 'Aircraft', 'Seats', 'Crew'],
            array_map(function($voucher) {
                return [
                    $voucher['flight_number'],
                    $voucher['flight_date'],
                    $voucher['aircraft_type'],
                    "{$voucher['seat1']}, {$voucher['seat2']}, {$voucher['seat3']}",
                    $voucher['crew_name']
                ];
            }, $sampleVouchers)
        );
    }
}

// Optional: Create a separate seeder for aircraft types if needed
class AircraftTypeSeeder extends Seeder
{
    public function run(): void
    {
        // This could be used if you create an aircraft_types table
        $aircraftTypes = [
            ['name' => 'ATR', 'rows' => 18, 'seats_per_row' => 4],
            ['name' => 'Airbus 320', 'rows' => 32, 'seats_per_row' => 6],
            ['name' => 'Boeing 737 Max', 'rows' => 32, 'seats_per_row' => 6],
        ];

        $this->command->info('Aircraft types configured successfully!');
    }
}