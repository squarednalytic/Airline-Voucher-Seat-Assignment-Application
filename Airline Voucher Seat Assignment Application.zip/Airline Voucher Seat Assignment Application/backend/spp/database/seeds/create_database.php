<?php

// backend/database/create_database.php

$databasePath = __DIR__ . '/vouchers.db';

try {
    // Check if database file already exists
    if (file_exists($databasePath)) {
        echo "Database file already exists at: $databasePath\n";
        
        // Ask if user wants to overwrite
        echo "Do you want to overwrite it? (yes/no): ";
        $handle = fopen("php://stdin", "r");
        $line = fgets($handle);
        if (trim(strtolower($line)) !== 'yes') {
            echo "Keeping existing database file.\n";
            exit(0);
        }
        
        // Remove existing file
        unlink($databasePath);
        echo "Removed existing database file.\n";
    }
    
    // Create new SQLite database
    $pdo = new PDO('sqlite:' . $databasePath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "SQLite database created successfully at: $databasePath\n";
    
    // Test connection
    $result = $pdo->query("SELECT sqlite_version()")->fetch();
    echo "SQLite Version: " . $result[0] . "\n";
    
    // Set file permissions
    chmod($databasePath, 0664);
    echo "File permissions set to 664\n";
    
} catch (PDOException $e) {
    echo "Error creating database: " . $e->getMessage() . "\n";
    exit(1);
}