<?php

namespace Tests\Unit;

use Tests\TestCase;
use App\Services\SeatGeneratorService;

class SeatGeneratorServiceTest extends TestCase
{
    protected SeatGeneratorService $seatGenerator;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seatGenerator = new SeatGeneratorService();
    }

    /** @test */
    public function it_generates_three_unique_seats()
    {
        $seats = $this->seatGenerator->generateSeats('Airbus 320');
        
        $this->assertCount(3, $seats);
        $this->assertEquals(3, count(array_unique($seats)));
    }

    /** @test */
    public function it_generates_valid_seats_for_atr()
    {
        $seats = $this->seatGenerator->generateSeats('ATR');
        
        foreach ($seats as $seat) {
            $this->assertTrue($this->seatGenerator->isValidSeat($seat, 'ATR'));
        }
    }

    /** @test */
    public function it_generates_valid_seats_for_airbus_320()
    {
        $seats = $this->seatGenerator->generateSeats('Airbus 320');
        
        foreach ($seats as $seat) {
            $this->assertTrue($this->seatGenerator->isValidSeat($seat, 'Airbus 320'));
        }
    }

    /** @test */
    public function it_generates_valid_seats_for_boeing_737()
    {
        $seats = $this->seatGenerator->generateSeats('Boeing 737 Max');
        
        foreach ($seats as $seat) {
            $this->assertTrue($this->seatGenerator->isValidSeat($seat, 'Boeing 737 Max'));
        }
    }

    /** @test */
    public function it_throws_exception_for_invalid_aircraft_type()
    {
        $this->expectException(\Exception::class);
        $this->seatGenerator->generateSeats('Invalid Aircraft');
    }

    /** @test */
    public function it_correctly_validates_seats_for_atr()
    {
        // Valid ATR seats
        $this->assertTrue($this->seatGenerator->isValidSeat('1A', 'ATR'));
        $this->assertTrue($this->seatGenerator->isValidSeat('18F', 'ATR'));
        $this->assertTrue($this->seatGenerator->isValidSeat('10D', 'ATR'));

        // Invalid ATR seats
        $this->assertFalse($this->seatGenerator->isValidSeat('19A', 'ATR')); // Row 19 doesn't exist
        $this->assertFalse($this->seatGenerator->isValidSeat('1B', 'ATR')); // Seat B doesn't exist
        $this->assertFalse($this->seatGenerator->isValidSeat('0A', 'ATR')); // Row 0 doesn't exist
    }

    /** @test */
    public function it_correctly_validates_seats_for_airbus_320()
    {
        // Valid Airbus 320 seats
        $this->assertTrue($this->seatGenerator->isValidSeat('1A', 'Airbus 320'));
        $this->assertTrue($this->seatGenerator->isValidSeat('32F', 'Airbus 320'));
        $this->assertTrue($this->seatGenerator->isValidSeat('15E', 'Airbus 320'));

        // Invalid Airbus 320 seats
        $this->assertFalse($this->seatGenerator->isValidSeat('33A', 'Airbus 320')); // Row 33 doesn't exist
        $this->assertFalse($this->seatGenerator->isValidSeat('1G', 'Airbus 320')); // Seat G doesn't exist
    }

    /** @test */
    public function it_generates_different_seats_on_subsequent_calls()
    {
        $seats1 = $this->seatGenerator->generateSeats('Airbus 320');
        $seats2 = $this->seatGenerator->generateSeats('Airbus 320');
        
        // Note: There's a small chance they could be the same
        // So we run multiple iterations to be more confident
        $different = false;
        for ($i = 0; $i < 10; $i++) {
            $seats1 = $this->seatGenerator->generateSeats('Airbus 320');
            $seats2 = $this->seatGenerator->generateSeats('Airbus 320');
            if ($seats1 !== $seats2) {
                $different = true;
                break;
            }
        }
        
        $this->assertTrue($different, 'Seats should be different across generations');
    }
}