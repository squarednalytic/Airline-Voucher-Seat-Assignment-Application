<?php

namespace Tests;

use Illuminate\Foundation\Testing\TestCase as BaseTestCase;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;

abstract class TestCase extends BaseTestCase
{
    use CreatesApplication;

    /**
     * Indicates whether the default seeder should run before each test.
     *
     * @var bool
     */
    protected $seed = false;

    /**
     * Setup the test environment before each test.
     */
    protected function setUp(): void
    {
        parent::setUp();

        // Use SQLite in-memory database for testing
        config(['database.default' => 'sqlite']);
        config(['database.connections.sqlite.database' => ':memory:']);

        // Run migrations
        $this->artisan('migrate:fresh');
        
        // Disable foreign key checks for SQLite
        DB::statement('PRAGMA foreign_keys = OFF;');
    }

    /**
     * Clean up the testing environment before the next test.
     */
    protected function tearDown(): void
    {
        // Re-enable foreign key checks
        DB::statement('PRAGMA foreign_keys = ON;');
        
        parent::tearDown();
    }

    /**
     * Create a test voucher record.
     *
     * @param array $attributes
     * @return \App\Models\Voucher
     */
    protected function createTestVoucher(array $attributes = [])
    {
        $defaults = [
            'crew_name' => 'Test Crew',
            'crew_id' => 'TC12345',
            'flight_number' => 'TEST101',
            'flight_date' => now()->addDay()->format('Y-m-d'),
            'aircraft_type' => 'Airbus 320',
            'seat1' => '1A',
            'seat2' => '1B',
            'seat3' => '1C'
        ];

        return \App\Models\Voucher::create(array_merge($defaults, $attributes));
    }

    /**
     * Generate a random flight number.
     *
     * @return string
     */
    protected function generateFlightNumber(): string
    {
        $airlines = ['GA', 'ID', 'JT', 'QZ', 'IN'];
        return $airlines[array_rand($airlines)] . rand(100, 999);
    }

    /**
     * Generate a random aircraft type.
     *
     * @return string
     */
    protected function generateAircraftType(): string
    {
        $types = ['ATR', 'Airbus 320', 'Boeing 737 Max'];
        return $types[array_rand($types)];
    }

    /**
     * Assert that the response has a valid seat structure.
     *
     * @param \Illuminate\Testing\TestResponse $response
     * @param string $aircraftType
     */
    protected function assertValidSeats($response, string $aircraftType)
    {
        $seats = $response->json('seats');
        
        $this->assertIsArray($seats);
        $this->assertCount(3, $seats);
        
        foreach ($seats as $seat) {
            $this->assertMatchesRegularExpression('/^\d+[A-Z]$/', $seat);
        }
    }
}