<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Voucher;

class VoucherApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_can_check_voucher_existence()
    {
        $response = $this->postJson('/api/check', [
            'flightNumber' => 'GA102',
            'date' => '2025-07-12'
        ]);

        $response->assertStatus(200)
                 ->assertJson(['exists' => false]);
    }

    public function test_can_generate_vouchers()
    {
        $response = $this->postJson('/api/generate', [
            'name' => 'Sarah',
            'id' => '98123',
            'flightNumber' => 'ID102',
            'date' => '2025-07-12',
            'aircraft' => 'Airbus 320'
        ]);

        $response->assertStatus(201)
                 ->assertJsonStructure([
                     'success',
                     'seats' => ['*']
                 ]);

        $this->assertDatabaseHas('vouchers', [
            'flight_number' => 'ID102',
            'flight_date' => '2025-07-12'
        ]);
    }

    public function test_prevents_duplicate_voucher_generation()
    {
        $this->postJson('/api/generate', [
            'name' => 'Sarah',
            'id' => '98123',
            'flightNumber' => 'ID102',
            'date' => '2025-07-12',
            'aircraft' => 'Airbus 320'
        ]);

        $response = $this->postJson('/api/generate', [
            'name' => 'John',
            'id' => '98124',
            'flightNumber' => 'ID102',
            'date' => '2025-07-12',
            'aircraft' => 'Airbus 320'
        ]);

        $response->assertStatus(409)
                 ->assertJson([
                     'success' => false,
                     'message' => 'Vouchers already exist for this flight and date'
                 ]);
    }
}