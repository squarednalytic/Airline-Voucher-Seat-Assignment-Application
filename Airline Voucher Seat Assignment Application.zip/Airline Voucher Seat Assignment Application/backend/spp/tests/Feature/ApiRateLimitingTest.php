<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\RateLimiter;

class ApiRateLimitingTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_limits_api_requests()
    {
        // Make multiple requests quickly
        for ($i = 0; $i < 10; $i++) {
            $response = $this->postJson('/api/check', [
                'flightNumber' => 'GA102',
                'date' => '2025-07-12'
            ]);
            
            // Should all succeed under normal limits
            $response->assertStatus(200);
        }
    }

    /** @test */
    public function it_handles_malformed_json_gracefully()
    {
        $response = $this->postJson('/api/generate', [
            'name' => 'Test',
            'id' => '123',
            // Missing required fields
        ]);

        $response->assertStatus(422);
    }
}