<?php

namespace App\Services;

use Exception;

class SeatGeneratorService
{
    private array $aircraftLayouts = [
        'ATR' => [
            'rows' => 18,
            'seats' => ['A', 'C', 'D', 'F'],
            'totalSeats' => 72
        ],
        'Airbus 320' => [
            'rows' => 32,
            'seats' => ['A', 'B', 'C', 'D', 'E', 'F'],
            'totalSeats' => 192
        ],
        'Boeing 737 Max' => [
            'rows' => 32,
            'seats' => ['A', 'B', 'C', 'D', 'E', 'F'],
            'totalSeats' => 192
        ]
    ];

    public function generateSeats(string $aircraftType): array
    {
        if (!isset($this->aircraftLayouts[$aircraftType])) {
            throw new Exception("Invalid aircraft type: {$aircraftType}");
        }

        $layout = $this->aircraftLayouts[$aircraftType];
        $allSeats = $this->generateAllSeats($layout);
        
        $selectedKeys = array_rand($allSeats, 3);
        $selectedSeats = [];
        
        foreach ($selectedKeys as $key) {
            $selectedSeats[] = $allSeats[$key];
        }
        
        sort($selectedSeats);
        return $selectedSeats;
    }

    private function generateAllSeats(array $layout): array
    {
        $seats = [];
        
        for ($row = 1; $row <= $layout['rows']; $row++) {
            foreach ($layout['seats'] as $seat) {
                $seats[] = $row . $seat;
            }
        }
        
        return $seats;
    }

    public function isValidSeat(string $seat, string $aircraftType): bool
    {
        if (!isset($this->aircraftLayouts[$aircraftType])) {
            return false;
        }

        $layout = $this->aircraftLayouts[$aircraftType];
        
        preg_match('/^(\d+)([A-Z])$/', $seat, $matches);
        
        if (count($matches) !== 3) {
            return false;
        }
        
        $row = (int)$matches[1];
        $seatLetter = $matches[2];
        
        return $row >= 1 && 
               $row <= $layout['rows'] && 
               in_array($seatLetter, $layout['seats']);
    }
}