<?php
// app/Http/Controllers/VoucherController.php

namespace App\Http\Controllers;

use App\Http\Requests\CheckVoucherRequest;
use App\Http\Requests\GenerateVoucherRequest;
use App\Http\Resources\CheckResource;
use App\Http\Resources\GenerateResource;
use App\Models\Voucher;
use App\Services\SeatGeneratorService;
use Illuminate\Http\JsonResponse;
use Illuminate\Database\QueryException;

class VoucherController extends Controller
{
    public function __construct(
        private SeatGeneratorService $seatGenerator
    ) {}

    /**
     * Check if vouchers exist for flight and date
     */
    public function check(CheckVoucherRequest $request): JsonResponse
    {
        $exists = Voucher::where('flight_number', $request->flightNumber)
            ->where('flight_date', $request->date)
            ->exists();

        return response()->json(new CheckResource($exists));
    }

    /**
     * Generate new voucher seats
     */
    public function generate(GenerateVoucherRequest $request): JsonResponse
    {
        try {
            // Check if vouchers already exist
            $exists = Voucher::where('flight_number', $request->flightNumber)
                ->where('flight_date', $request->date)
                ->exists();

            if ($exists) {
                return response()->json([
                    'success' => false,
                    'message' => 'Vouchers have already been generated for this flight and date'
                ], 409); // Conflict
            }

            // Generate 3 random unique seats
            $seats = $this->seatGenerator->generateSeats($request->aircraft);

            // Create voucher record
            $voucher = Voucher::create([
                'crew_name' => $request->name,
                'crew_id' => $request->id,
                'flight_number' => $request->flightNumber,
                'flight_date' => $request->date,
                'aircraft_type' => $request->aircraft,
                'seat1' => $seats[0],
                'seat2' => $seats[1],
                'seat3' => $seats[2]
            ]);

            return response()->json(new GenerateResource($voucher), 201);

        } catch (QueryException $e) {
            // Handle duplicate entry (unique constraint)
            if ($e->errorInfo[1] == 1062 || $e->errorInfo[1] == 19) { // MySQL or SQLite duplicate entry
                return response()->json([
                    'success' => false,
                    'message' => 'Vouchers already exist for this flight and date'
                ], 409);
            }

            throw $e;
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate vouchers: ' . $e->getMessage()
            ], 500);
        }
    }
}