<?php

// backend/test_database.php

try {
    // Load environment
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->load();
    
    $databasePath = $_ENV['DB_DATABASE'] ?? database_path('vouchers.db');
    
    echo "Testing database connection...\n";
    echo "Database path: {$databasePath}\n\n";
    
    // Check if file exists
    if (!file_exists($databasePath)) {
        echo "❌ Database file does not exist\n";
        exit(1);
    }
    
    echo "✅ Database file exists\n";
    
    // Check permissions
    if (!is_readable($databasePath)) {
        echo "❌ Database file is not readable\n";
        exit(1);
    }
    echo "✅ Database file is readable\n";
    
    if (!is_writable($databasePath)) {
        echo "❌ Database file is not writable\n";
        exit(1);
    }
    echo "✅ Database file is writable\n";
    
    // Test PDO connection
    $pdo = new PDO('sqlite:' . $databasePath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "✅ PDO connection successful\n";
    
    // Get SQLite version
    $version = $pdo->query('SELECT sqlite_version()')->fetchColumn();
    echo "✅ SQLite version: {$version}\n";
    
    // Check if tables exist
    $tables = $pdo->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
    echo "\nExisting tables:\n";
    foreach ($tables as $table) {
        echo "  - {$table}\n";
    }
    
    // Check vouchers table structure if it exists
    if (in_array('vouchers', $tables)) {
        $columns = $pdo->query("PRAGMA table_info(vouchers)")->fetchAll(PDO::FETCH_ASSOC);
        echo "\nVouchers table columns:\n";
        foreach ($columns as $column) {
            echo "  - {$column['name']} ({$column['type']})\n";
        }
        
        // Count records
        $count = $pdo->query('SELECT COUNT(*) FROM vouchers')->fetchColumn();
        echo "\nTotal voucher records: {$count}\n";
    }
    
} catch (PDOException $e) {
    echo "❌ Database error: " . $e->getMessage() . "\n";
    exit(1);
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}