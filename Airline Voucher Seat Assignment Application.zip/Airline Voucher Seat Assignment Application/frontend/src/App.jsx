import React, { useState } from 'react';
import VoucherForm from './components/VoucherForm';
import SeatDisplay from './components/SeatDisplay';
import ErrorMessage from './components/ErrorMessage';
import { generateVouchers } from './services/api';
import './styles/App.css';

function App() {
  const [seats, setSeats] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerate = async (formData) => {
    setLoading(true);
    setError('');
    setSeats(null);

    try {
      const result = await generateVouchers(formData);
      setSeats(result.seats);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Airline Voucher Seat Assignment</h1>
        <p className="subtitle">Crew Member Portal</p>
      </header>

      <main className="app-main">
        <VoucherForm onSubmit={handleGenerate} loading={loading} />
        
        {error && <ErrorMessage message={error} />}
        
        {seats && <SeatDisplay seats={seats} />}
      </main>

      <footer className="app-footer">
        <p>© 2024 Astronacci International - Technical Assessment</p>
      </footer>
    </div>
  );
}

export default App;