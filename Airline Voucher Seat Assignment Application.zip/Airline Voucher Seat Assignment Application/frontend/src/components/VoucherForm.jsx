import React, { useState } from 'react';

const aircraftTypes = ['ATR', 'Airbus 320', 'Boeing 737 Max'];

function VoucherForm({ onSubmit, loading }) {
  const [formData, setFormData] = useState({
    crewName: '',
    crewId: '',
    flightNumber: '',
    flightDate: '',
    aircraft: 'Airbus 320'
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.crewName || !formData.crewId || !formData.flightNumber || !formData.flightDate) {
      alert('Please fill in all fields');
      return;
    }

    // Validate date format (DD-MM-YYYY)
    const dateRegex = /^\d{2}-\d{2}-\d{4}$/;
    if (!dateRegex.test(formData.flightDate)) {
      alert('Please enter date in DD-MM-YYYY format');
      return;
    }

    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="voucher-form">
      <div className="form-grid">
        <div className="form-group">
          <label htmlFor="crewName">Crew Name *</label>
          <input
            type="text"
            id="crewName"
            name="crewName"
            value={formData.crewName}
            onChange={handleChange}
            placeholder="Enter crew name"
            disabled={loading}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="crewId">Crew ID *</label>
          <input
            type="text"
            id="crewId"
            name="crewId"
            value={formData.crewId}
            onChange={handleChange}
            placeholder="Enter crew ID"
            disabled={loading}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="flightNumber">Flight Number *</label>
          <input
            type="text"
            id="flightNumber"
            name="flightNumber"
            value={formData.flightNumber}
            onChange={handleChange}
            placeholder="e.g., GA102"
            disabled={loading}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="flightDate">Flight Date (DD-MM-YYYY) *</label>
          <input
            type="text"
            id="flightDate"
            name="flightDate"
            value={formData.flightDate}
            onChange={handleChange}
            placeholder="12-07-2025"
            disabled={loading}
            required
          />
        </div>

        <div className="form-group full-width">
          <label htmlFor="aircraft">Aircraft Type *</label>
          <select
            id="aircraft"
            name="aircraft"
            value={formData.aircraft}
            onChange={handleChange}
            disabled={loading}
            required
          >
            {aircraftTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
      </div>

      <button 
        type="submit" 
        className="generate-btn"
        disabled={loading}
      >
        {loading ? (
          <>
            <span className="spinner"></span>
            Generating...
          </>
        ) : (
          'Generate Vouchers'
        )}
      </button>
    </form>
  );
}

export default VoucherForm;