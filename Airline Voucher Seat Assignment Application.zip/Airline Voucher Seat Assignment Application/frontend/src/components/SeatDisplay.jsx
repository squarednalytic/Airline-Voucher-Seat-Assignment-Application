import React from 'react';

function SeatDisplay({ seats }) {
  return (
    <div className="seat-display-container">
      <h2>Voucher Seats Generated Successfully!</h2>
      <div className="seats-grid">
        {seats.map((seat, index) => (
          <div key={index} className="seat-card">
            <div className="seat-label">Seat {index + 1}</div>
            <div className="seat-number">{seat}</div>
          </div>
        ))}
      </div>
      <div className="success-message">
        <p>These 3 seats have been assigned to voucher winners.</p>
        <p className="small">Please provide these seat numbers to the winners.</p>
      </div>
    </div>
  );
}

export default SeatDisplay;