const API_BASE_URL = 'http://localhost:8000/api';

const formatDateForAPI = (dateStr) => {
  if (!dateStr) return '';
  const [day, month, year] = dateStr.split('-');
  return `${year}-${month}-${day}`;
};

export const generateVouchers = async (formData) => {
  const apiDate = formatDateForAPI(formData.flightDate);

  try {
    // Step 1: Check if vouchers exist
    const checkResponse = await fetch(`${API_BASE_URL}/check`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        flightNumber: formData.flightNumber,
        date: apiDate
      })
    });

    if (!checkResponse.ok) {
      throw new Error('Failed to check voucher existence');
    }

    const checkData = await checkResponse.json();

    if (checkData.exists) {
      throw new Error('Vouchers have already been generated for this flight and date');
    }

    // Step 2: Generate vouchers
    const generateResponse = await fetch(`${API_BASE_URL}/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: formData.crewName,
        id: formData.crewId,
        flightNumber: formData.flightNumber,
        date: apiDate,
        aircraft: formData.aircraft
      })
    });

    const generateData = await generateResponse.json();

    if (!generateResponse.ok) {
      throw new Error(generateData.message || 'Failed to generate vouchers');
    }

    return generateData;
  } catch (error) {
    throw error;
  }
};