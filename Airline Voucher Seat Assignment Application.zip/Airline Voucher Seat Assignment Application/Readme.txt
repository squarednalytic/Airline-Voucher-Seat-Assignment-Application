# Airline Voucher Seat Assignment Application

A full-stack application for airline crew members to generate random seat vouchers for promotional campaigns.

## Tech Stack

- **Frontend**: React.js
- **Backend**: Laravel 10.x
- **Database**: SQLite

## Prerequisites

- PHP 8.2+
- Composer
- Node.js 18+
- npm or yarn
- SQLite3

## Installation
